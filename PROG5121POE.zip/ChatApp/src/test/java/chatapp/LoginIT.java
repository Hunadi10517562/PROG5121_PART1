/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package chatapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class LoginIT {
    
    public LoginIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checkUserName method, of class Login.
     */
    @Test
public void testRegisterUser_valid() {
    Login instance = new Login();
    String result = instance.registerUser("Hunadi", "Sekele", "Hun_4", "Hunadi@9!");
    assertEquals("Username and Password successfully captured.", result);
}

    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String password = "Hunadi@9";
        Login instance = new Login();
        boolean expResult = true;
        boolean result = instance.checkPasswordComplexity(password);
        assertEquals("Password successfully captured.", result);        
    }

    /**
     * Test of checkCellPhoneNumber method, of class Login.
     */
    @Test
    public void testCheckCellPhoneNumber() {
        System.out.println("checkCellPhoneNumber");
        String phoneNumber = "+27646784269";
        Login instance = new Login();
        boolean expResult = true;
        boolean result = instance.checkCellPhoneNumber(phoneNumber);
        assertEquals("CellPhoneNumber (+27646784269) successfully captured.", result);       
    }

    /**
     * Test of registerUser method, of class Login.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String name = "Hunadi";
        String surname = "Sekele";
        String username = "Hun_4";
        String password = "Hunadi@9";
        Login instance = new Login();
        String expResult = "";
        String result = instance.registerUser(name, surname, username, password);
        assertEquals("name,surname,username,password successfully captured.", result);        
    }

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String username = "Hun_4";
        String password = "Hunadi@9";
        Login instance = new Login();
        boolean expResult = true;
        boolean result = instance.loginUser(username, password);
        assertEquals("username and password successfully captured.", result);       
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean isLoggedIn = true;
        Login instance = new Login();
        String expResult = "";
        String result = instance.returnLoginStatus(isLoggedIn);
        assertEquals(expResult, result);       
    }

    /**
     * Test of checkUserName method, of class Login.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        String username = "";
        Login instance = new Login();
        boolean expResult = true;
        boolean result = instance.checkUserName(username);
        assertEquals("username successfully captured.", result);       
    }
    
}
