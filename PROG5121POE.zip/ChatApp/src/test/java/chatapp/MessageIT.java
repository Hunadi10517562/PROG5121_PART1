/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package chatapp;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class MessageIT {
    
    public MessageIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createMessageID method, of class Message.
     */
    @Test
    public void testCreateMessageID() {
        System.out.println("createMessageID");
        int messageNumber = 0838884567;
        String expResult = "It is dinner time!";
        String result = Message.createMessageID(messageNumber);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of generateMessageHash method, of class Message.
     */
    @Test
    public void testGenerateMessageHash() {
        System.out.println("generateMessageHash");
        String msgID = "2";
        String messageText = "2";
        String expResult = "1";
        String result = Message.generateMessageHash(msgID, messageText);
        assertEquals("Where are you? You are late! I have asked you to be on time" successfully deleted, result);
        
    }

    /**
     * Test of validateMessageLength method, of class Message.
     */
    @Test
    public void testValidateMessageLength() {
        System.out.println("validateMessageLength");
        String text = "Where are you? You are late! I have asked you to be on time";
        String expResult = "";
        String result = Message.validateMessageLength(text);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of checkRecipientCell method, of class Message.
     */
    @Test
    public void testCheckRecipientCell() {
        System.out.println("checkRecipientCell");
        Message instance = null;
        String expResult = "+27646784269";
        String result = instance.checkRecipientCell();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of sentMessage method, of class Message.
     */
    @Test
    public void testSentMessage() {
        System.out.println("sentMessage");
        String action = "Did you get the cake?" "It is dinner time";
        Message instance = null;
        String expResult = "";
        String result = instance.sentMessage(action);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of printSendersAndRecipients method, of class Message.
     */
    @Test
    public void testPrintSendersAndRecipients() {
        System.out.println("printSendersAndRecipients");
        Message.printSendersAndRecipients();
        
    }

    /**
     * Test of getLongestStoredMessage method, of class Message.
     */
    @Test
    public void testGetLongestStoredMessage() {
        System.out.println("getLongestStoredMessage");
        String expResult = "";
        String result = Message.getLongestStoredMessage();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of searchByMessageID method, of class Message.
     */
    @Test
    public void testSearchByMessageID() {
        System.out.println("searchByMessageID");
        String id = "";
        String expResult = "";
        String result = Message.searchByMessageID(id);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of searchByRecipient method, of class Message.
     */
    @Test
    public void testSearchByRecipient() {
        System.out.println("searchByRecipient");
        String target = "";
        ArrayList<String> expResult = null;
        ArrayList<String> result = Message.searchByRecipient(target);
        assertEquals(expResult, result);
       
    }

    /**
     * Test of deleteByHash method, of class Message.
     */
    @Test
    public void testDeleteByHash() {
        System.out.println("deleteByHash");
        String hash = "";
        boolean expResult = true;
        boolean result = Message.deleteByHash(hash);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of displayReport method, of class Message.
     */
    @Test
    public void testDisplayReport() {
        System.out.println("displayReport");
        Message.displayReport();
       
    }

    /**
     * Test of saveToJSON method, of class Message.
     */
    @Test
    public void testSaveToJSON() {
        System.out.println("saveToJSON");
        Message msg = null;
        Message.saveToJSON(msg);
      
    }

    /**
     * Test of loadFromJSON method, of class Message.
     */
    @Test
    public void testLoadFromJSON() {
        System.out.println("loadFromJSON");
        Message.loadFromJSON();
       
    }

    /**
     * Test of getMessageID method, of class Message.
     */
    @Test
    public void testGetMessageID() {
        System.out.println("getMessageID");
        Message instance = null;
        String expResult = "";
        String result = instance.getMessageID();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of getMessageHash method, of class Message.
     */
    @Test
    public void testGetMessageHash() {
        System.out.println("getMessageHash");
        Message instance = null;
        String expResult = "";
        String result = instance.getMessageHash();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of getRecipient method, of class Message.
     */
    @Test
    public void testGetRecipient() {
        System.out.println("getRecipient");
        Message instance = null;
        String expResult = "";
        String result = instance.getRecipient();
        assertEquals(expResult, result);
      
    }

    /**
     * Test of getSender method, of class Message.
     */
    @Test
    public void testGetSender() {
        System.out.println("getSender");
        Message instance = null;
        String expResult = "";
        String result = instance.getSender();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of getMessageText method, of class Message.
     */
    @Test
    public void testGetMessageText() {
        System.out.println("getMessageText");
        Message instance = null;
        String expResult = "";
        String result = instance.getMessageText();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of returnTotalMessages method, of class Message.
     */
    @Test
    public void testReturnTotalMessages() {
        System.out.println("returnTotalMessages");
        int expResult = 0;
        int result = Message.returnTotalMessages();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of toString method, of class Message.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Message instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
       
    }
    
}
