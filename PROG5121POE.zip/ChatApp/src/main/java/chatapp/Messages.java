package chatapp;

public class Messages {

    
    public static String validateMessageLength(String messageText) {
        if (messageText == null || messageText.isEmpty()) {
            return "Error: Message body cannot be empty.";
        }
        if (messageText.length() > 250) {
            return "Error: Message exceeds the maximum of 250 characters.";
        }
        return "Message ready to send.";
    }
}