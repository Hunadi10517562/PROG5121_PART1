package chatapp;

public class Message {

    //Static counters / arrays
    private static int totalMessagesSent = 0;

    public static java.util.ArrayList<Message> sentMessages        = new java.util.ArrayList<>();
    public static java.util.ArrayList<Message> disregardedMessages = new java.util.ArrayList<>();
    public static java.util.ArrayList<Message> storedMessages      = new java.util.ArrayList<>();
    public static java.util.ArrayList<String>  messageHashes       = new java.util.ArrayList<>();
    public static java.util.ArrayList<String>  messageIDs          = new java.util.ArrayList<>();

    // Illustration fields
    private int    messageNumber;
    private String sender;     
    private String recipient;
    private String messageText;
    private String messageID;
    private String messageHash;

    // Initializer
    public Message(int messageNumber, String sender, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.sender        = sender;
        this.recipient     = recipient;
        this.messageText   = messageText;
        this.messageID     = createMessageID(messageNumber);
        this.messageHash   = generateMessageHash(this.messageID, messageText);
    }

    //Backwards-compatible initializer (for no sender) 
    public Message(int messageNumber, String recipient, String messageText) {
        this(messageNumber, "Unknown", recipient, messageText);
    }

    // ID & Hash generation

    // Creates a 10-digit random message ID.
    public static String createMessageID(int messageNumber) {
        long id = (long)(Math.random() * 4_000_000_000L) + 2_000_000_000L;
        return String.valueOf(id);
    }

    // Hash format:  FIRST2OFID : WORD_COUNT : LAST_WORD  (all uppercase)
    public static String generateMessageHash(String msgID, String messageText) {
        if (msgID == null || msgID.length() < 2) return "";
        String prefix  = msgID.substring(0, 2);
        String[] words = messageText.trim().split("n+");
        String lastWord = words[words.length - 1].toUpperCase();
        return (prefix + ":" + words.length + ":" + lastWord).toUpperCase();
    }

    // Validation 

    // Static length validator used from ChatApp
    public static String validateMessageLength(String text) {
        if (text == null || text.isEmpty()) {
            return "Message cannot be empty.";
        } else if (text.length() > 250) {
            return "Message exceeds 250 characters.";
        }
        return "Message ready to send.";
    }

    // Validate the recipient cell number stored in this instance
    public String checkRecipientCell() {
        if (recipient == null) return "Recipient number is null.";
        // Accept +27XXXXXXXXX (SA international) or 10-digit local
        if (recipient.matches("\\+27[6-8]\\d{8}") || recipient.matches("0[6-8]\\d{8}") || recipient.matches("\\d{10}")) {
            return "Cell number successfully added.";
        }
        return "Warning: Recipient number format might be invalid.";
    }

    //Action processing

    //Processes send / disregard / store and updates the static arrays.
    public String sentMessage(String action) {
        switch (action.toLowerCase()) {
            case "send":
                totalMessagesSent++;
                sentMessages.add(this);
                messageHashes.add(this.messageHash);
                messageIDs.add(this.messageID);
                saveToJSON(this);
                return "Message successfully sent.";

            case "disregard":
                disregardedMessages.add(this);
                return "Message discarded.";

            case "store":
                storedMessages.add(this);
                messageHashes.add(this.messageHash);
                messageIDs.add(this.messageID);
                saveToJSON(this);
                return "Message stored for later.";

            default:
                return "Unknown action.";
        }
    }

    //Stored Messages operations

    // a. Print sender & recipient of every stored message
    public static void printSendersAndRecipients() {
        if (storedMessages.isEmpty()) { System.out.println("No stored messages."); return; }
        System.out.println("Senders & Recipients (Stored) ──");
        for (Message m : storedMessages)
            System.out.println("Sender: " + m.sender + " | Recipient: " + m.recipient);
    }

    // b. Return (and print) the longest stored message
    public static String getLongestStoredMessage() {
        if (storedMessages.isEmpty()) return "";
        String longest = "";
        for (Message m : storedMessages)
            if (m.messageText.length() > longest.length()) longest = m.messageText;
        System.out.println("Longest stored message: \"" + longest + "\"");
        return longest;
    }

    // c. Search by message ID = returns the message text or empty string
    public static String searchByMessageID(String id) {
        for (Message m : sentMessages)
            if (m.messageID.equals(id)) { printMessageDetails(m); return m.messageText; }
        for (Message m : storedMessages)
            if (m.messageID.equals(id)) { printMessageDetails(m); return m.messageText; }
        System.out.println("Message ID \"" + id + "\" not found.");
        return "";
    }

    private static void printMessageDetails(Message m) {
        System.out.println("Recipient : " + m.recipient);
        System.out.println("Message   : " + m.messageText);
    }

    // d. Search ALL messages (sent + stored) for a specific recipient
    public static java.util.ArrayList<String> searchByRecipient(String target) {
        java.util.ArrayList<String> results = new java.util.ArrayList<>();
        for (Message m : sentMessages)
            if (m.recipient.equals(target)) results.add(m.messageText);
        for (Message m : storedMessages)
            if (m.recipient.equals(target)) results.add(m.messageText);
        if (results.isEmpty())
            System.out.println("No messages found for recipient: " + target);
        else {
            System.out.println("Messages for " + target + ":");
            for (String msg : results) System.out.println("  \"" + msg + "\"");
        }
        return results;
    }

    // e. Delete a stored message by hash. Returns true if found & deleted
    public static boolean deleteByHash(String hash) {
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedMessages.get(i).messageHash.equals(hash)) {
                String msg = storedMessages.get(i).messageText;
                storedMessages.remove(i);
                messageHashes.remove(hash);
                System.out.println("Message: \"" + msg + "\" successfully deleted.");
                return true;
            }
        }
        System.out.println("Hash \"" + hash + "\" not found in stored messages.");
        return false;
    }

    // f. Print a full report of ALL sent messages (hash, recipient, message)
    public static void displayReport() {
        System.out.println(" FULL REPORT ");
        System.out.printf("%-5s %-20s %-45s %-30s%n","No.", "Recipient", "Message", "Hash");
        System.out.println("─".repeat(100));

        System.out.println("SENT");
        for (int i = 0; i < sentMessages.size(); i++) {
            Message m = sentMessages.get(i);
            System.out.printf("%-5d %-20s %-45s %-30s%n",
                    i + 1, m.recipient, truncate(m.messageText, 44), m.messageHash);
        }

        System.out.println("STORED");
        for (int i = 0; i < storedMessages.size(); i++) {
            Message m = storedMessages.get(i);
            System.out.printf("%-5d %-20s %-45s %-30s%n",
                    i + 1, m.recipient, truncate(m.messageText, 44), m.messageHash);
        }
        System.out.println("═".repeat(100));
    }

    //JSON persistence

    public static void saveToJSON(Message msg) {
        try {
            java.io.File f = new java.io.File("messages.json");
            StringBuilder sb = new StringBuilder();
            if (f.exists()) {
                String content = new String(java.nio.file.Files.readAllBytes(f.toPath())).trim();
                if (content.startsWith("[") && content.endsWith("]"))
                    sb.append(content, 0, content.length() - 1);
                else sb.append("[");
            } else {
                sb.append("[");
            }
            if (sb.length() > 1) sb.append(",");
            sb.append("\n  {");
            sb.append("\"sender\":\"").append(esc(msg.sender)).append("\",");
            sb.append("\"recipient\":\"").append(esc(msg.recipient)).append("\",");
            sb.append("\"message\":\"").append(esc(msg.messageText)).append("\",");
            sb.append("\"messageID\":\"").append(msg.messageID).append("\",");
            sb.append("\"messageHash\":\"").append(msg.messageHash).append("\"");
            sb.append("}");
            sb.append("\n]");
            java.nio.file.Files.write(f.toPath(), sb.toString().getBytes());
        } catch (java.io.IOException e) {
            System.out.println("JSON save error: " + e.getMessage());
        }
    }

    public static void loadFromJSON() {
        try {
            java.io.File f = new java.io.File("messages.json");
            if (!f.exists()) return;
            storedMessages.clear();
            String content = new String(java.nio.file.Files.readAllBytes(f.toPath())).trim();
            int pos = 0;
            while ((pos = content.indexOf("{", pos)) != -1) {
                int end = content.indexOf("}", pos);
                if (end == -1) break;
                String obj    = content.substring(pos + 1, end);
                String sender = jsonVal(obj, "sender");
                String recip  = jsonVal(obj, "recipient");
                String text   = jsonVal(obj, "message");
                String id     = jsonVal(obj, "messageID");
                String hash   = jsonVal(obj, "messageHash");
                Message m = new Message(0, sender, recip, text);
                m.messageID   = id;
                m.messageHash = hash;
                storedMessages.add(m);
                pos = end + 1;
            }
        } catch (java.io.IOException e) {
            System.out.println("JSON load error: " + e.getMessage());
        }
    }

    //Getters 
    public String getMessageID()   { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient()   { return recipient; }
    public String getSender()      { return sender; }
    public String getMessageText() { return messageText; }
    public static int returnTotalMessages() { return totalMessagesSent; }

    //Helpers
    private static String esc(String s)             
    { return s == null ? "" : s.replace("\"", "\\\""); }
    private static String jsonVal(String obj, String key) {
        String search = "\"" + key + "\":\"";
        int s = obj.indexOf(search);
        if (s == -1) return "";
        s += search.length();
        int e = obj.indexOf("\"", s);
        return e == -1 ? "" : obj.substring(s, e);
    }
    private static String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 3) + "...";
    }

    @Override
    public String toString() {
        return "ID: "        + messageID   + "\n" +
               "Hash: "      + messageHash + "\n" +
               "To: "        + recipient   + "\n" +
               "From: "      + sender      + "\n" +
               "Message: "   + messageText;
    }
}