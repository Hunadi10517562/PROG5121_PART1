package chatapp;

import java.util.Scanner;

public class CHATAPP {

    private static Scanner scanner = new Scanner(System.in);
    private static Login auth = new Login(); 
    private static boolean loggedIn = false;

    public static void main(String[] args) {

        //1. REGISTRATION
        System.out.println("Welcome to QuickChat 2026: Registration");
        System.out.print("Enter your First Name: ");
        String name = scanner.nextLine().trim();
        
        System.out.print("Enter your Surname: ");
        String surname = scanner.nextLine().trim();
        
        System.out.print("Create a Username (must contain '_' and max 5 characters): ");
        String username = scanner.nextLine().trim();
        
        System.out.print("Create a Password (min 8 chars, 1 Uppercase, 1 Digit, 1 Special): ");
        String password = scanner.nextLine().trim();

        String regMessage = auth.registerUser(name, surname, username, password);
        System.out.println("\n" + regMessage);

        // if registration checks do not pass
        if (!regMessage.equals("Username and Password successfully captured.")) {
            System.out.println("Registration failed. Exiting application.");
            return;
        }

        //2. CELLPHONE VALIDATION
        System.out.print("Enter Phone number (+27 format): ");
        String phoneInput = scanner.nextLine().trim();
        if (auth.checkCellPhoneNumber(phoneInput)) {
            System.out.println("Cell number successfully captured.\n");
        } else {
            System.out.println("Cell number incorrectly formatted or does not contain international code. Exiting application.");
            return;
        }

        //3. LOGIN
        System.out.println("QuickChat Login");
        System.out.print("Enter Username: ");
        String loginUser = scanner.nextLine().trim();
        System.out.print("Enter Password: ");
        String loginPass = scanner.nextLine().trim();
        
        // Check invalid credentials
        loggedIn = auth.loginUser(loginUser, loginPass);
        System.out.println(auth.returnLoginStatus(loggedIn));

        if (!loggedIn) {
            System.out.println("Exiting QuickChat due to invalid credentials.");
            return;
        }

        // MAIN CHAT APPLICATION 
        System.out.print("How many messages would you like to send this session? ");
        int numMessages = Integer.parseInt(scanner.nextLine().trim());
        int messagesSentThisSession = 0;

        boolean running = true;
        while (running) {
            System.out.println("Main Menu");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> {
                    if (messagesSentThisSession >= numMessages) {
                        System.out.println("You have reached your message limit for this session.");
                    } else {
                        sendMessage(messagesSentThisSession + 1);
                        messagesSentThisSession++;
                    }
                }

                case "2" -> System.out.println("Coming Soon.");

                case "3" -> {
                    running = false;
                    System.out.println("Total messages sent: " + Message.returnTotalMessages());
                    System.out.println("Goodbye!");
                }

                default -> System.out.println("Invalid option. Please try again.");
            }
        }
    }

    //SEND MESSAGE METHOD
    private static void sendMessage(int messageNumber) {
        System.out.print("Enter recipient cell number: ");
        String recipient = scanner.nextLine().trim();

        System.out.print("Enter your message: ");
        String messageText = scanner.nextLine().trim();

        String lengthCheck = Messages.validateMessageLength(messageText);
        if (!lengthCheck.equals("Message ready to send.")) {
            System.out.println(lengthCheck);
            return;
        }

        Message msg = new Message(messageNumber, recipient, messageText);
        System.out.println(msg.checkRecipientCell());
        System.out.println("Message ID generated: " + msg.getMessageID());

        System.out.println("What would you like to do?");
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        System.out.print("Choose: ");
        String action = scanner.nextLine().trim();

        String result;
        switch (action) {
            case "1":
                result = msg.sentMessage("send");
                break;
            case "2":
                result = msg.sentMessage("disregard");
                break;
            case "3":
                result = msg.sentMessage("store");
                break;
            default:
                result = "Invalid option.";
        }

        System.out.println(result);

        if (action.equals("1")) {
            System.out.println("Message Details");
            System.out.println(msg.toString());
        }

        System.out.println("Total messages sent so far: " + Message.returnTotalMessages());
    }
}