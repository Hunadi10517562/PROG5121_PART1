package chatapp;



public class Message {
    private static int totalMessagesSent = 0;
    
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageID;

    // Constructor
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = "MSG-" + messageNumber + "-" + (int)(Math.random() * 10);
    }

    // Static method to validate text length
    public static String validateMessageLength(String text) {
        if (text == null || text.isEmpty()) {
            return "Message cannot be empty.";
        } else if (text.length() > 250) {
            return "Message is too long (Max 250 characters).";
        }
        return "Message ready to send.";
    }

    // Validate cell number
    public String checkRecipientCell() {
        if (recipient.matches("\\d{10}")) { 
// Checks for a 10-digit number and should contain international code
            return "Recipient number format is valid.";
        }
        return "Warning: Recipient number format might be invalid.";
    }
//Message hash with ID,a colon(:) and number of message
    public String getMessageID() {
        return this.messageID;
    }

    // Process action and return status
    public String sentMessage(String action) {
        switch (action.toLowerCase()) {
            case "send":
                totalMessagesSent++;
                return "Message successfully sent!";
            case "disregard":
                return "Message discarded.";
            case "store":
                return "Message saved to drafts.";
            default:
                return "Unknown action.";
        }
    }

    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    @Override
    public String toString() {
        return "ID: " + messageID + "To: " + recipient + "Content: " + messageText;
    }
}
