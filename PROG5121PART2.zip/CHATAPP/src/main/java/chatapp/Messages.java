package chatapp;

public class Messages {
    public static String validateMessageLength(String messageText) {
        if (messageText == null || messageText.isEmpty()) {
            return "Error: Message body cannot be empty.";
        }
        if (messageText.length() > 160) {
            return "Error: Message length exceeds maximum standard limit of 160 characters.";
        }
        return "Message ready to send.";
    }
}