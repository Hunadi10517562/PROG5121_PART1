package chatapp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
  Assessment: Prog5121 Part1 (Login and Registration System)
 */
public class Login {
    private String firstName; 
    private String lastName;
    private String registeredUsername;
    private String registeredPassword;

    // 1. Check Username formatting
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // 2. Password Complexity Validator
    public boolean checkPasswordComplexity(String password) {
        if (password == null) return false;
        
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = password.matches(".*[!@#$%^&*()\\-+].*");

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            if (Character.isDigit(c)) hasDigit = true;
        }

        return password.length() >= 8 && hasUpper && hasDigit && hasSpecial;
    }

    // 3. SA Phone Number Parser (+27 followed by exactly 9 digits)
    public boolean checkCellPhoneNumber(String phoneNumber) {
        if (phoneNumber == null) return false;
        // Matches +27 followed by a 6, 7, or 8, and then 8 additional digits (Total 9 digits after country code)
        String regex = "^\\+27[6-8]\\d{8}$"; 
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(phoneNumber);
        return matcher.matches();
    }

    // 4. Registration Process 
    public String registerUser(String name, String surname, String username, String password) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your "
                 + "username contains an underscore and is no more than five characters in length.";
        }
        
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the "
                 + "password contains at least eight characters, a capital letter, a number and a special character.";
        }

        this.firstName = name;
        this.lastName = surname;
        this.registeredUsername = username;
        this.registeredPassword = password;
        return "Username and Password successfully captured.";
    }

    // 5. Dynamic Login Authentication Check
    public boolean loginUser(String username, String password) {
        if (username == null || password == null) return false;
        return username.equals(this.registeredUsername) && password.equals(this.registeredPassword);
    }

    // 6. Formatted Login Status Response
    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}