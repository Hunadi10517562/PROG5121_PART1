package login;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
  Assessment: Prog5121 Part1 (Login and Registration System)
  Attributes: International Regex for Phone Validation
 */

public class Login {
    // Instance variables to store data for the testable methods
    private String firstName; 
    private String lastName;
    private String registeredUsername;
    private String registeredPassword;

    // 1. Boolean: checkUserName()
    // Returns true if username contains underscore and is <= 5 chars
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // 2. Boolean: check PasswordComplexity()
    // Ensure password has 8 characters, Capital letter, Number and a Special Character
    public boolean checkPasswordComplexity(String password) {
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = password.matches(".*[!@#$%^&*()\\-+].*");

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            if (Character.isDigit(c)) hasDigit = true;
        }

        return password.length() >= 8 && hasUpper &&hasDigit && hasSpecial;
    }

    // 3. Boolean: checkCellPhoneNumber()
    // Research-based Regex: Checks for +27 followed by 9 digits
    public boolean checkCellPhoneNumber(String phoneNumber) {
        // Reference: Regular expression for SA International code (+27)
        String regex = "^\\+27[6-8]\\[8]"; 
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(phoneNumber);
        return matcher.matches();
    }

    // 4. String: registerUser()
    // Returns the success or failure messages from the assessment table
    public String registerUser(String Name,String Surname,String username, String password) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your "
                 + "username contains an underscore and is no more than five characters in length.";
        }
        
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the "
                 + "password contains at least eight characters, a capital letter, a number and a special character.";
        }

        // Capture information if valided
        this.firstName = Name;
        this.lastName = Surname;
        this.registeredUsername = username;
        this.registeredPassword = password;
        return "Username and Password successfully captured.";
    }

    // 5. Boolean: loginUser()
    // Verify if details entered matches registration details
    public boolean loginUser(String username, String password) {
        if (username == null || password == null) return false;
        return username.equals(this.registeredUsername) && password.equals(this.registeredPassword);
    }

    // 6. String: returnLoginStatus()
    // Return the welcome or error message
    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Main Menu 
    public static void main(String[] args) {
        Login auth = new Login();
        Scanner sc = new Scanner(System.in);
       
        System.out.println("Welcome to chat app 2026! Please Register your account...");
        System.out.print("Enter your First Name: ");
        String Name = sc.nextLine();
        
        System.out.print("Enter your Surname: ");
        String Surname = sc.nextLine();
        
        System.out.print("Enter Username: ");
        String username = sc.nextLine();
        
        System.out.print("Enter Password: ");
        String password = sc.nextLine();
        
        // Register and show every message
        String regMessage = auth.registerUser(Name,Surname,username, password);
        System.out.println(regMessage);

        // Only proceed if registration was successful
        if (regMessage.equals("Username and Password successfully captured.")) {
            System.out.print("Enter Phone (+27..): ");
            String regex = sc.nextLine();
            if (auth.checkCellPhoneNumber(regex)) {
                System.out.println("Cell number successfully captured.");
                
                System.out.println("Welcome to chat app 2026 again!... Please Login...");
                System.out.print("Enter Username: ");
                String loginUser = sc.nextLine();
                System.out.print("Enter Password: ");
                String loginPass = sc.nextLine();
                
                boolean status = auth.loginUser(loginUser, loginPass);
                System.out.println(auth.returnLoginStatus(status));
            } else {
                System.out.println("Cell number incorrectly formatted or does not contain international code. please correct the number and try again");
            }
        }
        sc.close();
    }
}